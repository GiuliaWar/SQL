CREATE DATABASE ToysGroup;

-- CREAZIONE TABELLA PRODUCT

CREATE TABLE PRODUCT (
    ID_PRODOTTO VARCHAR(255) NOT NULL UNIQUE PRIMARY KEY,
    CATEGORIA VARCHAR(255) NOT NULL,
    GIOCO VARCHAR(255) NOT NULL,
    COSTO DOUBLE
);

-- POPOLAMENTO TABELLA PRODUCT

 INSERT INTO PRODUCT value
		("A000", "Bambole e Peluches", "Barbie", 25.00),
        ("B000", "Bambole e Peluches", "Orsetto", 15.00),
        ("C000", "Action Figures", "Spiderman", 30.00),
        ("D000", "Action Figures", "Pompieri", 40.00),
        ("E000", "Giochi di SocietÃ ", "Uno", 10.00),
        ("F000", "Giochi di societÃ ", "Risiko", 35.00) ;

-- SELECT PROVA
SELECT 
    *
FROM
    PRODUCT;

-- CREAZIONE TABELLA REGION

CREATE TABLE REGION (
    ID_REGION VARCHAR(255) NOT NULL UNIQUE PRIMARY KEY,
    STATI VARCHAR(255) NOT NULL
);

-- POPOLAMENTO TABELLA REGION

INSERT INTO REGION value
		("USA_01", "Ohio"),
        ("USA_35","Texas"),
        ("EU_007", "France"),
        ("AF_001","Algeria"),
        ("ME_09","Turkey"),
        ("AS_01", "China") ;

-- SELECT PROVA
SELECT 
    *
FROM
    REGION;

-- CREAZIONE TABELLA SALES

CREATE TABLE SALES (
    ID_SALE INT NOT NULL UNIQUE PRIMARY KEY
);
 
-- POPOLAMENTO TABELLA SALES

INSERT INTO SALES value
		(1),
        (2),
        (3),
        (4),
        (5),
        (6),
        (7),
        (8),
        (9);

-- SELECT PROVA
SELECT 
    *
FROM
    SALES;
    
-- CREAZIONE TABELLA VENDITA

CREATE TABLE VENDITA (
    ID_VENDITA INT NOT NULL UNIQUE PRIMARY KEY,
    ID_PRODOTTO VARCHAR(255) NOT NULL,
    ID_SALE INT NOT NULL UNIQUE,
    DATA_ACQUISTO DATE,
    FOREIGN KEY (ID_PRODOTTO)
        REFERENCES PRODUCT (ID_PRODOTTO),
    FOREIGN KEY (ID_SALE)
        REFERENCES SALES (ID_SALE)
);

-- POPOLAMENTO TABELLA VENDITA

INSERT INTO VENDITA values
		(005, "D000", 1, "2022-09-18"),
        (003, "B000", 2, "2023-10-10"),
        (001, "A000", 3, "2023-12-01"),
        (006, "D000", 4, "2024-01-06"),
        (007, "D000", 5, "2024-02-07"),
        (008, "D000", 6, "2024-02-10"),
        (002, "A000", 7, "2024-02-14"),
        (004, "C000", 8, "2024-02-20"),
        (009, "F000", 9, "2024-02-24");

-- SELECT PROVA
SELECT 
    *
FROM
    VENDITA;

-- CREAZIONE TABELLA MERCATO

CREATE TABLE MERCATO (
    ID_MERCATO INT NOT NULL UNIQUE PRIMARY KEY,
    ID_SALE INT NOT NULL UNIQUE,
    ID_REGION VARCHAR(255) NOT NULL,
    FOREIGN KEY (ID_SALE)
        REFERENCES SALES (ID_SALE),
    FOREIGN KEY (ID_REGION)
        REFERENCES REGION (ID_REGION)
);

-- POPOLAMENTO TABELLA MERCATO

insert into MERCATO values
		(01, 1, "USA_01"),
        (02, 2, "USA_01"),
        (03, 3, "ME_09"),
        (04, 4, "AF_001"),
        (05, 5, "AF_001"),
        (06, 6, "EU_007"),
        (07, 7, "AS_01"),
        (08, 8, "AS_01"),
        (09, 9, "AS_01");

-- SELECT PROVA
SELECT 
    *
FROM
    MERCATO;
    
-- INIZIO SVOLGIMENTO ESERCIZIO
   
-- Verificare che i campi definiti come PK siano univoci

show columns FROM PRODUCT;
SELECT DISTINCT
    id_prodotto
FROM
    PRODUCT;
show columns FROM REGION;
SELECT DISTINCT
    id_region
FROM
    REGION;
show columns FROM SALES;
SELECT DISTINCT
    id_sale
FROM
    SALES;
show columns FROM MERCATO;
SELECT DISTINCT
    id_mercato
FROM
    MERCATO;
show columns FROM VENDITA;
SELECT DISTINCT
    id_vendita
FROM
    VENDITA;
    
-- Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno

SELECT 
    YEAR(DATA_ACQUISTO) AS ANNO_VENDITA,
    product.ID_PRODOTTO,
    SUM(COSTO) AS FATTURATO_ANNUO
FROM
    VENDITA
        JOIN
    PRODUCT ON VENDITA.ID_PRODOTTO = PRODUCT.ID_PRODOTTO
GROUP BY ANNO_VENDITA , ID_PRODOTTO;
  
-- Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente

SELECT 
    R.STATI,
    YEAR(V.DATA_ACQUISTO) AS ANNO,
    SUM(P.COSTO) AS FATTURATO
FROM
    VENDITA V
        JOIN
    PRODUCT P ON V.ID_PRODOTTO = P.ID_PRODOTTO
        JOIN
    MERCATO M ON V.ID_SALE = M.ID_SALE
        JOIN
    REGION R ON M.ID_REGION = R.ID_REGION
GROUP BY R.STATI , YEAR(V.DATA_ACQUISTO)
ORDER BY FATTURATO DESC;

-- Qual è la categoria di articoli maggiormente richiesta dal mercato?

SELECT 
    CATEGORIA, COUNT(*) AS NUMERO_VENDITE
FROM
    PRODUCT
        JOIN
    VENDITA ON PRODUCT.ID_PRODOTTO = VENDITA.ID_PRODOTTO
        JOIN
    MERCATO ON VENDITA.ID_SALE = MERCATO.ID_SALE
GROUP BY CATEGORIA
ORDER BY NUMERO_VENDITE DESC
LIMIT 1;

-- Quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. 
-- Risoluzione 1 usando clausola "not in"

SELECT 
    CATEGORIA, GIOCO
FROM
    PRODUCT
WHERE
    ID_PRODOTTO NOT IN (SELECT 
            ID_PRODOTTO
        FROM
            VENDITA);
            
-- Risoluzione 2 usando clausola "null"

SELECT 
    CATEGORIA, GIOCO
FROM
    PRODUCT P
        LEFT JOIN
    VENDITA V ON P.ID_PRODOTTO = V.ID_PRODOTTO
WHERE
    V.ID_VENDITA IS NULL;

-- Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente)

SELECT 
    p.ID_PRODOTTO,
    p.CATEGORIA,
    p.GIOCO,
    p.COSTO,
    v.DATA_ACQUISTO
FROM
    PRODUCT p
        LEFT JOIN
    VENDITA v ON p.ID_PRODOTTO = v.ID_PRODOTTO
ORDER BY v.DATA_ACQUISTO DESC;
  







